<?php
/*
Plugin Name: Qode Instagram Widget
Description: Plugin that adds Instagram feed functionality to our theme
Author: Qode Themes
Version: 1.2
*/
define('QODE_INSTAGRAM_WIDGET_VERSION', '1.2');

include_once 'load.php';